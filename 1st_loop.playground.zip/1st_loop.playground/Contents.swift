import UIKit

var password = "swordfish"

if password == "swordfish"{
print(password)
}


//while loop
var counter = 5

while counter > 0{
  print("hello")
    //counter = counter - 1
    counter -= 1
}


//repeat while loop
repeat {
print("hello2")
counter -= 1
    
}
while counter > 0

//functions
func addTwoNumbers(){
  let a = 1
  let b = 2
    
  let c = a + b
    
    print(c)
}

//create a function and assign a name
func subtractTwoNumbers(){
    let a = 1
    let d = 1
    let e = a-d
    print (e)
}
// to print the information in the function, call it outside with two brackets
subtractTwoNumbers()

func TwoNumbers(arg para: Int, arg2 para2: Int) -> Int {
    
    let a = para
    let b = 1
    return a + b
}

let sum = addTwoNumbers(arg: 2, arg2: 2)

print (sum)
